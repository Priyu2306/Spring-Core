package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.bo.MemberPolicyBO;
import com.cts.exception.MemberPolicyException;

@Component("memberPolicyService")
public class MemberPolicyService {
	
	@Autowired
	private  MemberPolicyBO memberPolicyBO;

	


	public void updatePremiumAmount(String planId, String memberId, String corporateName) throws MemberPolicyException
	{
		memberPolicyBO.updatePremiumAmount(planId, memberId, corporateName);
	}

}

package com.cts.bean;

import java.util.Map;

public class TestDetailsVO {
	
	private Map map;

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}
	
	

}

package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cts.bean.PlanVO;

public class PlanRowMapper implements RowMapper<PlanVO> {

	@Override
	public PlanVO mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		PlanVO plan = new PlanVO();
		plan.setPlanId(rs.getString("Plan_Id"));
		plan.setPlanName(rs.getString("Plan_name"));
		plan.setPlanValue(rs.getString("Plan_value"));
		plan.setTenure(rs.getInt("tenure"));
		return plan;
	}

}

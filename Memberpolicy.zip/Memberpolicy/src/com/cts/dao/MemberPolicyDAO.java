package com.cts.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.cts.bean.MemberVO;
import com.cts.bean.PlanVO;

@Repository
public class MemberPolicyDAO extends JdbcDaoSupport {
	
	//DataSource dataSource;
	//JdbcTemplate jdbcTemplate;
	
	public MemberVO getPlanDetailsOfMember(String memberId)
	{
		MemberVO member = new MemberVO();
		PlanVO plan= new PlanVO();
		String query= "select * from member_details where member_Id=?";
		member= getJdbcTemplate().queryForObject(query, new Object[] {memberId}, new MemberDetailRowMapper());
		String q= "SELECT * from plan_details where Plan_id=(select plan_id from member_details where Member_Id=?)";
		plan= getJdbcTemplate().queryForObject(q, new Object[] {memberId}, new PlanRowMapper());
		member.setPlan(plan);
		return member;
	}
	
	public void updatePremiumAmount(Double premiumAmount,String memberId)
	{
		String query="update member_details set premium_amount=? where member_id=?";
		getJdbcTemplate().update(query,new Object[] {premiumAmount,memberId});
		System.out.println("Successfully updtaed");
	}

}

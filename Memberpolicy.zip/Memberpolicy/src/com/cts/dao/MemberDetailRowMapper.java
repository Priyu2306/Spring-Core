package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cts.bean.MemberVO;

public class MemberDetailRowMapper implements RowMapper<MemberVO> {

	@Override
	public MemberVO mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		MemberVO member= new MemberVO();
		member.setCorporateName(rs.getString("Corporate_Name"));
		member.setMaturityDate(rs.getDate("Monthyly_due_date"));
		member.setMemberId(rs.getString("Member_id"));
		member.setMemberName(rs.getString("member_name"));
		member.setPlanId(rs.getString("plan_id"));
		member.setPremiumAmount(rs.getInt("premium_amount"));
		
		return member;
	}

}

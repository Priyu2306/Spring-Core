package com.cts.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.exception.MemberPolicyException;
import com.cts.service.MemberPolicyService;

public class MemberPolicyMain {
	
	
	public static void main(String[] args) throws MemberPolicyException {
		ApplicationContext context= new ClassPathXmlApplicationContext("bean.xml");
		MemberPolicyService memberPolicyService = (MemberPolicyService) context.getBean("memberPolicyService");
		
		memberPolicyService.updatePremiumAmount("PA0001", "M001", "IT");
		
	}
	
	
}

package com.cts.bo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.bean.MemberVO;
import com.cts.bean.TestDetailsVO;
import com.cts.dao.MemberPolicyDAO;
import com.cts.exception.MemberPolicyException;

@Component("memberPolicyBO")
public class MemberPolicyBO {
	
	@Autowired
	private  MemberPolicyDAO memberDao;
	@Autowired
	private  TestDetailsVO testCollection;
	
	public void updatePremiumAmount(String planId, String memberId, String corporateName) throws MemberPolicyException
	{
		Double premiumAmount=0.0;
		int discpuntPercentage=0;
		Map<String,String> testMap= new HashMap<String,String>();
		testMap = testCollection.getMap();
		for(Map.Entry<String, String> entry : testMap.entrySet())
		{
			if(corporateName.equalsIgnoreCase(entry.getKey()))
			{
				discpuntPercentage= Integer.parseInt(entry.getValue());
			}
		}
		MemberVO member= memberDao.getPlanDetailsOfMember(memberId);
		if(member!= null)
		{
			
			premiumAmount=calculatePremiumAmount(discpuntPercentage, member);
			memberDao.updatePremiumAmount(premiumAmount, memberId);
		}
		else
		{
			throw new MemberPolicyException("Invalid Plan Id for the given member");
		}
		
		
	}
	
	public double calculatePremiumAmount(int discpuntPercentage, MemberVO member)
	{
		Double premiumAmount=0.0;
		premiumAmount=(double) (Double.parseDouble(member.getPlan().getPlanValue())*discpuntPercentage);	
	
		
		
		return premiumAmount;
	}

}
